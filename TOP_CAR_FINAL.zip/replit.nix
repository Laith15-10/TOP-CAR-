{pkgs}: {
  deps = [
    pkgs.gettext
  ];
}
